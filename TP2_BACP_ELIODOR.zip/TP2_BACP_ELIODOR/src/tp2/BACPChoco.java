package tp2;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import choco.Choco;
import choco.cp.model.CPModel;
import choco.cp.solver.CPSolver;
import choco.kernel.model.variables.integer.IntegerVariable;


public class BACPChoco {

	// input
	int n;// number of courses
	int p;// number of periods
	BACPChoco cc = new BACPChoco();
	int  L;//Nombre de contraintes de precedence
	int[] t;// c[i] number of credits of course i
	int minCourses;//nombre minimum de cours pour chaque periode 
	int maxCourses;//nombre maximum de cours pour chaque periode
	int minCredits;//nombre minimum de credits pour chaque periode
	int maxCredits;//nombre minimum de credits pour chaque periode
	int [] I;//Contient les premiers elements des pairs de cours representant les contraintes de precedence
	int [] J;//Contient les seconds elements des pairs de cours representant les contraintes de precedence
	int [] c;//Tableau des credits des cours

	int nombreProfs;
	int maxCoursProf;
	CPModel m;
	CPSolver s;
	private Scanner in;




	public void readData(String fn){

		try{
			in = new Scanner(new File(fn));
			n = in.nextInt();//Nombre de cours
			p = in.nextInt();//nombre de periodes
			minCredits = in.nextInt();//Contrainte minCredits A
			maxCredits = in.nextInt();//Contrainte maxCredits B
			minCourses = in.nextInt();//Contrainte minCourses C
			maxCourses = in.nextInt();//Contrainte maxCourses D
			c = new int[n];//Initialisation du tableau des credits des cours
			for(int i = 0; i < n; i++){
				c[i] = in.nextInt();
			}

			L = in.nextInt();//Lecture du nombre de contraintes de precedence
			I = new int [L];
			J = new int [L];

			// Ajout des pairs pour les contraintes de precedence
			for(int i = 0; i < L; i++){
				I[i] = in.nextInt() -1;
				J[i] = in.nextInt() -1;
			}
			//Lecture des valeurs pour le nombre de profs et le nombre de cours par profs
			nombreProfs=in.nextInt();
			maxCoursProf=in.nextInt();

		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}


	@SuppressWarnings("deprecation")
	public void search (int timeLimit, String filename){

		timeLimit = timeLimit* 1000;//Calcul de la limite de temps

		m = new CPModel ();//Initialisation du modele

		//Affectation des cours pour une periode donnees
		IntegerVariable[] x= new IntegerVariable[n];//tableau d'assignation des periodes aux cours	
		for (int i = 0; i< n; i++)
			x[i]= Choco.makeIntVar("x[" + i + "]", 0,p-1);//Creation des IntegerVariable avec des plages de domaine D={0,1}	
		
		//Affectation des cours pour toutes les periodes
		IntegerVariable [][] y = new IntegerVariable [n][p];//Tableau d'aasignation des cours aux periodes
		for (int i = 0; i< n; i++)
			for (int j = 0; j < p; j++)
				y[i][j]= Choco.makeIntVar("y[" + i + ","+ j + "]", 0,1);//Creation des IntegerVariable avec des plages de domaine D={0,1}	


		//Mise en place des contraintes de verification entre les deux tableaux (Coherence entre les deux tableaux)
		for (int i = 0; i< n; i++) 
			for (int j = 0; j < p; j++){
				m.addConstraint(Choco.implies(Choco.eq(x[i], j), Choco.eq(y[i][j], 1)));//
				m.addConstraint(Choco.implies(Choco.neq(x[i], j), Choco.eq(y[i][j], 0)));
			}

		//Ajout des contraintes de precedence des cours (Constraint on the prerequisite)
		for (int l = 0; l < L; l++) {
			m.addConstraint(Choco.lt(x[I[l]], x[J[l]]));
		}

		//Parcours du tableau du tableau a deux dimensions pour ajouter les contraintes
		for (int j = 0; j < p; j++) {
			IntegerVariable[] z= new IntegerVariable [n];//Declaration d'un vecteur d'IntegerVariable pour stocker les cours assignes pour chaque periode
			//Affectation des cours assignes pour chaque periode au vecteur. Correspondance entre les positions des cours entre le tableau et le vecteur
			for (int i = 0; i< n; i++){
				z[i]= y[i][j];
			}
			//Ajout des contraintes pour verifier que le nombre de cours assignes a chaque periode est compris entre  maxCourses et minCourses
			m.addConstraint(Choco.leq(Choco.sum(z), maxCourses));
			m.addConstraint(Choco.leq(minCourses,Choco.sum(z)));
			//Ajout des contraintes pour verifier que le nombre de credits total des cours assignes a chaque periode est compris entre  maxCredits et minCredits
			m.addConstraint(Choco.leq(Choco.scalar(z, c),maxCredits));
			m.addConstraint(Choco.leq(minCredits,Choco.scalar(z,  c)));
		}

		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		IntegerVariable[] B= new IntegerVariable[n];//Creation d'un vecteur(tableau) de longueur nombre de cours (n) de IntegerVariable permettant de stocker les professeurs associes a chaque cours   
		for (int i = 0; i< n; i++)
			B[i]= Choco.makeIntVar("x[" + i + "]", 0,nombreProfs-1);//Creation des IntegerVariable avec des plages de domaine D=[0,nombreProfs-1]	

		
		
		//Ajout de la contrainte permettant de verifier qu'un professeur a un et un seul cours dans une periode donnee
		for(int i=0;i<p;i++){			
			IntegerVariable[] cours = new IntegerVariable[n];//
			for(int j=0;j<n;j++) {
				cours[j]=y[j][i];
			}
			for(int l=0;l<n-1;l++) {
				for(int k=l+1;k<n;k++) {
					m.addConstraint(
							Choco.implies(
									Choco.and(Choco.eq(cours[l], 1),Choco.eq(cours[k], 1)),
									Choco.neq(B[l],B[k])
									)					
							);
					//Ajouter la contrainte definie plus haut dans le systeme de contraintes
				}
			}	
		}

		//Creation d'une matrice de dimensions (n x nombreProfs) contenant des IntegerVariable de domaine D={0,1} permettant de connaitre le professeur de chaque cours	
		IntegerVariable [][] T = new IntegerVariable [n][nombreProfs];
		for (int i = 0; i< n; i++)
			for (int j = 0; j < nombreProfs; j++)
				T[i][j]= Choco.makeIntVar("T[" + i + ","+ j + "]", 0,1);

		//Formulation la contrainte permettant de garder la coherence des informations entre les deux tableaux professeurs/cours B et T 
		for (int i = 0; i< n; i++) 
			for (int j = 0; j < nombreProfs; j++){
				m.addConstraint(Choco.implies(Choco.eq(B[i], j), Choco.eq(T[i][j], 1)));
				m.addConstraint(Choco.implies(Choco.neq(B[i], j), Choco.eq(T[i][j], 0)));
				
			}
		//m.addConstraint(Choco.neq(B[3], 1));
		
		/*for (int i = 0; i< n; i++)	
			m.addConstraint(Choco.implies(Choco.eq(x[i], 0), Choco.neq(B[i], 0)));*/
				
		
		//Ajout des contraintes pour le nombre de cours maximal a ne pas depasser pour les professeurs
		for (int j = 0; j < nombreProfs; j++) {
			IntegerVariable[] cours= new IntegerVariable [n];
			for (int i = 0; i< n; i++){
				cours[i]= T[i][j];
			}
			m.addConstraint(Choco.leq(Choco.sum(cours), maxCoursProf));//Ajout de la contrainte
		}
		
		/*for(int i=0; i<n; i++)
			for (int j=0; j<p; j++)
		m.addConstraint(Choco.eq(Choco.sum(x[i]), j), 8);*/

		//resolution
		s= new CPSolver();
		s.read(m);

		s.setTimeLimit(timeLimit);

		Boolean ok = s.solve();

		System.out.println("Solved =" + ok);
		for (int i = 0; i < n; i++)
			System.out.println("X[" + i + "]=" + s.getVar(x[i]).getVal());

		for(int P = 0; P < p; P++){
			System.out.print("period " + P + " : ");
			for(int i = 0; i < n; i++){
				if(s.getVar(x[i]).getVal() == P)
					System.out.print(i + " ");
			}
			System.out.println();
		}

		System.out.println();
		System.out.println();
		System.out.println("\n\n");
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				System.out.print(s.getVar(y[i][j]).getVal());
				System.out.print(" ");
			}
			System.out.println("");
		}
		System.out.println();
		System.out.println();

		for(int i=0;i<n;i++) {
			System.out.println(i + " : "+s.getVar(B[i]).getVal());			
		}
		System.out.println();
		System.out.println();

		System.out.println("\n\n");
		for(int i=0;i<n;i++) {
			for(int j=0;j<nombreProfs;j++) {
				System.out.print(s.getVar(T[i][j]).getVal());
				System.out.print(" ");
			}
			System.out.println("");
		}	

		System.out.println();
		System.out.println();

		for(int i=0;i<p;i++){
			System.out.println("Periode : " + i);
			for(int j=0; j<n;j++) {
				if(s.getVar(y[j][i]).getVal()==1) {
					System.out.print("Cours : "+j);
					System.out.println("\tProf : " + s.getVar(B[j]).getVal());
				}
			}
			System.out.println();
		}




		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		/*AFFICHAGE HTML*/
		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		try {
			File outFile = new File(filename+".html");
			PrintWriter out;
			out = new PrintWriter(outFile);
			out.println("<head>\n<title>"+filename+"</title>\n");
			out.println("<br/>\n<p1>File Name = "+filename+"</p1>\n<br/>\n<p2>Solve = "+ok+"</p2>\n<br/>");
			out.print("<p1>Time Limit = "+timeLimit+"<p1>\n<br/><br/>");
            out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
            out.println("</head>");
            out.print("<body>");
            out.print("<table border = 1 display=inline float=left>"); 
			
            out.print("</tr>");
			for(int i=0;i<p;i++) {
				out.print("<td>");
				out.print("<table border=1px height=220>");
				out.print("<tr>");
				out.print("<td style=\"font-weight:bold;color:red;text-align:center\" colspan=3>");
				out.println("Periode "+ i);
				out.println("</td></tr>");

				out.println("<tr>");
				out.println("<td>Cours</td>");
				out.println("<td>Enseignants</td>");
				out.println("<td>Credits</td>");
				out.println("</tr>");

				out.println("<tr>");
				out.println("<td>");
				for(int j=0;j<n;j++) {
					if(s.getVar(y[j][i]).getVal()==1) {
						out.println(j);
						out.print("<br />");
					}
				}
				out.println("</td>");						
				out.println("<td>");
				for(int j=0;j<n;j++) {
					if(s.getVar(y[j][i]).getVal()==1) {
						out.println(s.getVar(B[j]).getVal());
						out.print("<br />");
					}
				}
				out.print("</td>");							
				out.print("<td>");
				for(int j=0;j<n;j++) {
					if(s.getVar(y[j][i]).getVal()==1) {
						out.println(c[j]);
						out.print("<br />");
					}
				}
				out.print("</td>");
				out.print("</tr>");
				out.print("</table>");
				out.print("</td>");
			}
			out.print("</tr>");

			out.print("</table>");
			out.print("</body></html>");
			out.close();
		} catch (IOException exx) {
			exx.printStackTrace();
		}

	}


	public static void main(String[] args) {
		double t0=System.currentTimeMillis();
		BACPChoco bacp= new BACPChoco();
		String nomFichier="data/ex-bacp-c20-p5-t5.inp";
		bacp.readData(nomFichier);
		bacp.search(20,nomFichier);
		double t= System.currentTimeMillis() - t0;
		System.out.println("\ntime=" + t);	
	}

}
