

public class Item {
	int w, h;

	public Item(int w, int h) {
		this.w = w;
		this.h = h;
	}
}
